package com.smms.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smms.entities.Customer;
import com.smms.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepo;
	
	@Override
	public Customer saveCustomer(Customer customer) {
		return customerRepo.save(customer);
		
	}
	@Override
    public List<Customer> fetchCustomerList() {
        return customerRepo.findAll();
    }

   @Override
   public Customer fetchCustomerById(Long customerId) {
	   return customerRepo.findById(customerId).get();
   }
	
   @Override
   public void deleteCustomerById(Long customerId) {
	   customerRepo.deleteById(customerId);
   }


   @Override
   public Customer updateCustomer(Long customerId, Customer customer) {
	   Customer cusDB = customerRepo.findById(customerId).get();

       if(Objects.nonNull(customer.getCustomerName()) &&
       !"".equalsIgnoreCase(customer.getCustomerName())) {
    	   cusDB.setCustomerName(customer.getCustomerName());
       }

       if(Objects.nonNull(customer.getCustomerPhone())|| 
    		   (customer.getCustomerPhone() == null)) {
    	   cusDB.setCustomerPhone(customer.getCustomerPhone());
       }

       if(Objects.nonNull(customer.getCustomerEmail()) &&
               !"".equalsIgnoreCase(customer.getCustomerEmail())) {
    	   cusDB.setCustomerEmail(customer.getCustomerEmail());
       }

       return customerRepo.save(cusDB);
   }

    
}
