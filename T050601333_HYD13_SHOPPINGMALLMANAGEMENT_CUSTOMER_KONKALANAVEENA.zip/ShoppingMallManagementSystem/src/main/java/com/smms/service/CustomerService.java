package com.smms.service;

import java.util.List;

import com.smms.entities.Customer;


public interface CustomerService {
	
	public Customer saveCustomer(Customer customer);

	public List<Customer> fetchCustomerList();

	public Customer fetchCustomerById(Long customerId);

	public void deleteCustomerById(Long customerId);

	public Customer updateCustomer(Long customerId, Customer customer);

}
